package com.example.zootopia.dblayout;

/**
 * Created by Yilei Chu on 16/4/15.
 */
public interface DbHandlerIntf {
    public void createTable();
}
