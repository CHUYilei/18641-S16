package com.example.zootopia.adapter;

import com.example.zootopia.entities.Chatroom;
import com.example.zootopia.entities.User;

import java.util.List;

/**
 * Created by Zootopia on 5/2/16.
 * Linpeng Lyu (linpengl)
 * Yilei Chu (ychu1)
 * Jialu Chen (jialuc)
 */
public class UserContainer {
    public static User user;
    public static List<Chatroom> chatroomList;
}
