package servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

import database.DBQueryHandler;

@WebServlet("/profile")
public class ProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 4032239150708337925L;
	private static DBQueryHandler queryHandler;
	
	public void init(ServletConfig config) throws ServletException {
		if(queryHandler == null) queryHandler = new DBQueryHandler();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uid = request.getParameter("user_id");
		String email = request.getParameter("email");
		
		JSONObject profile;
		if (uid != null)
			profile = queryHandler.getJSONObject("user_profile", 
				"user_id", uid);
		else
			profile = queryHandler.getJSONObject("user_profile", 
					"email", email);

		if (profile == null) 
			profile = new JSONObject();
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(profile.toString());
	}	

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uid = request.getParameter("user_id");
		String uname = request.getParameter("user_name");
		String gender = request.getParameter("gender");
		String description = request.getParameter("description");
		Map<String, String> whereCondition = new HashMap<>();
		whereCondition.put("user_id", uid);
		queryHandler.updateRecord("user_profile", whereCondition, "user_name", uname,
				"gender", gender, "description", description);
		JSONObject jsonFinal = new JSONObject();		
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		try {
			jsonFinal.put("status", "200");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.getWriter().write(jsonFinal.toString());
	}
}
