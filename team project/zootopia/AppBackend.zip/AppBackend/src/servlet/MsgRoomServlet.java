package servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

import database.DBQueryHandler;

@WebServlet("/msgroom")
public class MsgRoomServlet extends HttpServlet {
	private static final long serialVersionUID = 4032239150708337925L;
	private static DBQueryHandler queryHandler;
	
	public void init(ServletConfig config) throws ServletException {
		if(queryHandler == null) queryHandler = new DBQueryHandler();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String msgId = request.getParameterValues("msg_id")[0];
		
		JSONObject jsonFinal = new JSONObject();		
		JSONObject msgChatRoom = queryHandler.getJSONObject("message_chatroom", "msg_id", msgId);
		try {
			if (msgChatRoom != null) {
				jsonFinal.put("message_chatroom", msgChatRoom);	
			} else {
				jsonFinal.put("message_chatroom", "");
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(jsonFinal.toString());
	}	

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String sender = request.getParameter("from_user_id");
		String receiver = request.getParameter("to_user_id");
		String roomId = request.getParameter("room_id");
		String title = request.getParameter("title");
		String content = request.getParameter("content");
		String status = request.getParameter("status");
		queryHandler.insertRecord("message_chatroom", "from_user_id", sender,
				"to_user_id", receiver, "room_id", roomId, "title", title,
				"content", content, "status", status);
		JSONObject jsonFinal = new JSONObject();		
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		try {
			jsonFinal.put("status", "200");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.getWriter().write(jsonFinal.toString());
	}
}
