package servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

import database.DBQueryHandler;

@WebServlet("/chatroom")
public class ChatroomServlet extends HttpServlet {
	private static final long serialVersionUID = 4032239150708337925L;
	private static DBQueryHandler queryHandler;
	
	public void init(ServletConfig config) throws ServletException {
		if(queryHandler == null) queryHandler = new DBQueryHandler();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String rid = request.getParameter("room_id");
		
		JSONObject profile = null;
		if (rid != null)
			profile = queryHandler.getJSONObject("chatroom_profile", "room_id", rid);
		
		if (profile == null) 
			profile = new JSONObject();

		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(profile.toString());
	}	

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uid = request.getParameter("host_id");
		String rname = request.getParameter("room_name");
		String description = request.getParameter("room_description");
		//Map<String, String> whereCondition = new HashMap<>();
		//whereCondition.put("user_id", uid);
		queryHandler.insertRecord("chatroom_profile", "host_id", uid,
				"room_name", rname, "room_description", description);
		String rid = queryHandler.getInsertId();
		
		// add host_id into member list
		queryHandler.insertRecord("chatroom_member_list", "user_id", uid,
				"room_id", rid);
		
		JSONObject jsonFinal = new JSONObject();		
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		try {
			jsonFinal.put("room_id", rid);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.getWriter().write(jsonFinal.toString());
	}
}

