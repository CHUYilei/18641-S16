package servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

import database.DBLoginHandler;
import database.DBUserProfileHandler;


@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 4032239150708437925L;
	private static DBLoginHandler dbLoginHandler;
	private static DBUserProfileHandler dbUserProfileHandler;
	
	public void init(ServletConfig config) throws ServletException {
		if(dbLoginHandler == null) dbLoginHandler = new DBLoginHandler();
		if(dbUserProfileHandler == null) dbUserProfileHandler = new DBUserProfileHandler();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String email = request.getParameter("email");
		String passwd = request.getParameter("passwd");

		
		/* validate login */
		
		JSONObject jsonFinal = new JSONObject();		
		int login_result = dbLoginHandler.checkLogin(email, passwd);
		
		try {
			if(login_result == DBLoginHandler.VERIFIED){
				jsonFinal.put("login_result", "verified");
				
				/* add other info */
				addUserProfile(jsonFinal,email);
				
			} else if(login_result == DBLoginHandler.NOT_MATCH){
				jsonFinal.put("login_result", "not_match");			
			} else if(login_result == DBLoginHandler.USER_NOT_FOUND){
				jsonFinal.put("login_result", "user_not_found");			
			} else if(login_result == DBLoginHandler.SQL_FAIL){
				jsonFinal.put("login_result", "sql_fail");			
			} 
		} catch (JSONException e) {
			e.printStackTrace();
		}

		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(jsonFinal.toString());
	}
	
	/* helper functions to add result from other tables */
	private void addUserProfile(JSONObject jsonFinal,String email){
		try {
			jsonFinal.put("user_profile",dbUserProfileHandler.getUserProfile(email));
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}