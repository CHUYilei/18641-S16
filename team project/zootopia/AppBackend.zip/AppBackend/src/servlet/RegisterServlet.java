package servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

import database.DBQueryHandler;

/**
 * Servlet implementation class RegisterServlet
 * 
 * URL:
 * http://localhost:8080/AppBackend/RegisterServlet?email=firstuser@abc.com&passwd=123&name=firstuser
 * 
 * will insert record into login database and return a user_id
 */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = -6200431678803199381L;
	
	private static DBQueryHandler queryHandler;
	
	public void init(ServletConfig config) throws ServletException {
		if(queryHandler == null) queryHandler = new DBQueryHandler();
	}


	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
		String passwd = request.getParameter("passwd");
		String name = request.getParameter("name");
		
		JSONObject jsonFinal = new JSONObject();
		/* check duplicate user */
		try{
			JSONObject profile = queryHandler.getJSONObject("user_profile", 
					"email", email);
			if( profile != null){ //already exists
				jsonFinal.put("user_id", -1);
				jsonFinal.put("error_status", "duplicate user");
			}else{
				queryHandler.insertRecord("user_login", "password", passwd, "email", email);
				queryHandler.insertRecord("user_profile", "user_name", name, "email", email,
						"description", "");
				JSONObject tmp = queryHandler.getJSONObject("user_profile", "email", email);
				jsonFinal.put("user_id", tmp.get("user_id"));
				jsonFinal.put("error_status", "no error");
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}

		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(jsonFinal.toString());
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
