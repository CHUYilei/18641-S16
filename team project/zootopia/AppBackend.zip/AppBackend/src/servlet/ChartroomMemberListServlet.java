package servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import database.DBQueryHandler;

@WebServlet("/chatroommember")
public class ChartroomMemberListServlet extends HttpServlet {
	private static final long serialVersionUID = 4032239150708337925L;
	private static DBQueryHandler queryHandler;
	
	public void init(ServletConfig config) throws ServletException {
		if(queryHandler == null) queryHandler = new DBQueryHandler();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String rid = request.getParameter("room_id");
		String uid = request.getParameter("user_id");

		JSONObject jsonFinal = new JSONObject();
		JSONArray memberList = null;
		JSONArray roomlist = null;
		if (rid != null) {
			String query = "select user_profile.* from user_profile, chatroom_member_list "
					+ "where chatroom_member_list.room_id=" + rid 
					+ " and user_profile.user_id=chatroom_member_list.user_id;";
			memberList = queryHandler.getJSONObjectArray(query);
		} else if (uid != null) {
			String query = "select room_id from chatroom_member_list where user_id = " + uid;
			roomlist = queryHandler.getJSONObjectArray(query);
		}

		try {
			if (rid != null && memberList != null) {
				jsonFinal.put("chatroom_member_list", memberList);	
			} else if (rid != null) {
				jsonFinal.put("chatroom_member_list", "[]");
			} else if (uid != null && roomlist != null) {
				jsonFinal.put("chatroom_list", roomlist);	
			} else if (uid != null) {
				jsonFinal.put("chatroom_list", "[]");	
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(jsonFinal.toString());
	}	

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uid = request.getParameter("user_id");
		String rid = request.getParameter("room_id");
		//Map<String, String> whereCondition = new HashMap<>();
		//whereCondition.put("user_id", uid);
		queryHandler.insertRecord("chatroom_member_list", "user_id", uid,
				"room_id", rid);
		JSONObject jsonFinal = new JSONObject();		
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		try {
			jsonFinal.put("status", "200");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.getWriter().write(jsonFinal.toString());
	}
	
	@Override
	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uid = request.getParameter("user_id");
		String rid = request.getParameter("room_id");
		Map<String, String> whereCondition = new HashMap<>();
		whereCondition.put("room_id", rid);
		if (uid != null)
			whereCondition.put("user_id", uid);
		// else delete all members in this room
		queryHandler.delelteRecord("chatroom_member_list", whereCondition);
		JSONObject jsonFinal = new JSONObject();		
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		try {
			jsonFinal.put("status", "200");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.getWriter().write(jsonFinal.toString());	
	}
}


