package servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import database.DBQueryHandler;

@WebServlet("/relation")
public class RelationShipServlet extends HttpServlet {
	private static final long serialVersionUID = -75102784279074411L;
	private static DBQueryHandler queryHandler;
	
	public void init(ServletConfig config) throws ServletException {
		if(queryHandler == null) queryHandler = new DBQueryHandler();
	}

	/**
	 * Get a list of friends
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uid = request.getParameter("user_id");
		JSONObject jsonFinal = new JSONObject();		
		String query = "select user_profile.* from user_profile, relationship "
				+ "where relationship.user_id=" + uid 
				+ " and user_profile.user_id=relationship.friend_id;";
		JSONArray profile = queryHandler.getJSONObjectArray(query);
		try {
			if (profile != null) {
				jsonFinal.put("user_profile", profile);	
			} else {
				jsonFinal.put("user_profile", "");
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(jsonFinal.toString());
	}	

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uid = request.getParameter("user_id");
		String friendId = request.getParameter("friend_id");
		JSONObject jsonFinal = new JSONObject();
		queryHandler.insertRecord("relationship", "user_id", uid,
				"friend_id", friendId);
		queryHandler.insertRecord("relationship", "user_id", friendId,
				"friend_id", uid);
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		try {
			jsonFinal.put("status", "200");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.getWriter().write(jsonFinal.toString());
	}
	
	@Override
	protected void doDelete(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uid = request.getParameter("user_id");
		String friendId = request.getParameter("friend_id");
		Map<String, String> whereCondition = new HashMap<>();
		whereCondition.put("user_id", uid);
		whereCondition.put("friend_id", friendId);
		queryHandler.delelteRecord("relationship", whereCondition);
		
		whereCondition.put("user_id", friendId);
		whereCondition.put("friend_id", uid);
		queryHandler.delelteRecord("relationship", whereCondition);
		
		JSONObject jsonFinal = new JSONObject();		
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		try {
			jsonFinal.put("status", "200");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.getWriter().write(jsonFinal.toString());	
	}

}

