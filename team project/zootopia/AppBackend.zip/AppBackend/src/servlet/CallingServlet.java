package servlet;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

import database.DBCallingHandler;
import database.DBLoginHandler;
import database.DBUserProfileHandler;

/**
 * Servlet implementation class CallingServlet
 * 
 * check whether I am busy as a callee
 * if I am busy, get the caller and room info
 * 
 * get:
 * http://localhost:8080/AppBackend/CallingServlet?callee_id=2
 * post:
 * http://localhost:8080/AppBackend/CallingServlet?callee_id=2&caller_id=1&room_id=1997&type=voice&room_name=haharoom
 */
@WebServlet("/CallingServlet")
public class CallingServlet extends HttpServlet {
	private static final long serialVersionUID = -6950733252293263400L;

	private static DBCallingHandler dbCallingHandler;
	
	public void init(ServletConfig config) throws ServletException {
		if(dbCallingHandler == null) dbCallingHandler = new DBCallingHandler();
	}
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 * get callee busy info
	 * 
	 * URL: callee_id:2
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int calleeID = Integer.parseInt(request.getParameterValues("callee_id")[0]);
		
		JSONObject jsonFinal = dbCallingHandler.isCalleeBusy(calleeID);
		
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(jsonFinal.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 * 
	 * update callee's caller and room info
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int calleeID = Integer.parseInt(request.getParameterValues("callee_id")[0]);
		int callerID = Integer.parseInt(request.getParameterValues("caller_id")[0]);
		int roomID = Integer.parseInt(request.getParameterValues("room_id")[0]);
		String type = request.getParameterValues("type")[0];
		String roomName = request.getParameterValues("room_name")[0];
		
		dbCallingHandler.updateCalling(calleeID, callerID, roomID,type,roomName);
		
		JSONObject jsonFinal = new JSONObject();
		try {
			jsonFinal.put("status", 200);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().write(jsonFinal.toString());
	}

}
