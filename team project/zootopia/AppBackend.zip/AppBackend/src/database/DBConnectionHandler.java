package database;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
	 
/**
 * 	Reference: http://www.javaknowledge.info/sample-login-app-in-android-using-servlet-and-json-parsing/
 */
public class DBConnectionHandler {
	private static final String dbName = "groupdb";
	private static final String user = "root";
	private static final String passwd = "";
	private static final String port = "3306";
	private static final String host = "localhost";
	private static String url = null;
	private static Connection connection = null;
	
	private static void init(){
		if(connection == null){
			// connect to mysql
			url = "jdbc:mysql://"+ host + ":" + port;
			
	        try {
	            Class.forName("com.mysql.jdbc.Driver");//Mysql Connection
	        } catch (ClassNotFoundException ex) {
	            Logger.getLogger(DBConnectionHandler.class.getName()).log(Level.SEVERE, null, ex);
	        }
			
			try {	
				connection = DriverManager.getConnection(url,user, passwd);
			} catch (SQLException e) {
				System.err.println("[DB] Cannot connect to mysql!");
				e.printStackTrace();
			} 
			
			if(connection != null){
				System.err.println("[DB] Connected to mysql!");
			}
			
			createDbIfNotExists();
			
			// connect to database
			url = "jdbc:mysql://"+ host + ":" + port + "/"+ dbName;
			try {	
				connection = DriverManager.getConnection(url,user, passwd);
			} catch (SQLException e) {
				System.err.println("[DB] Cannot connect to database "+dbName+"!");
				e.printStackTrace();
			} 
			
			if(connection != null){
				System.err.println("[DB] Connected to database "+dbName+"!");
			}	
		}
	}
	
	/**
	 * Create DB if not exists
	 */
	private static void createDbIfNotExists(){
		Statement statement;
		String[] sqls = {"create database IF NOT EXISTS "+dbName+";",
						"use "+dbName+";"};
		try{
			statement = connection.createStatement();
			for(String sql:sqls){
				statement.execute(sql);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection() {
		if(connection != null) return connection;
		
		System.err.println("[DB] initialize database");
		init();
	    return connection;
	}
	
	public static void executeSqlNoReturn(String sql){
		if(connection == null) {
			System.err.println("[DB] initialize database");
			init();
		}
		
		Statement statement;
		try{
			statement = connection.createStatement();
			statement.execute(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

