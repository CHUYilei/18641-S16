package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBLoginHandler {
	private static Connection connection = null;
	private static String tableName = "user_login";

	public static final int VERIFIED = 1;
	public static final int NOT_MATCH = 2;
	public static final int USER_NOT_FOUND = 3;
	public static final int SQL_FAIL = 4;

	public DBLoginHandler() {
		connection = DBConnectionHandler.getConnection();
		createTable();
		//insertRecord("sample@abc.com","123");
	}

	/**
	 * create table if not exists
	 */
	private void createTable() {
		String sql = "CREATE TABLE IF NOT EXISTS " + tableName
				+ "(email varchar(50) NOT NULL, password varchar(20), primary key(email));";
		DBConnectionHandler.executeSqlNoReturn(sql);
	}

	public int checkLogin(String email, String password) {
		PreparedStatement ps = null;
		ResultSet result = null;
		String realPassword = null;

		try {
			ps = connection.prepareStatement("select password from user_login where (email=?);");
			ps.setString(1, email);
			result = ps.executeQuery();

			if (result.next()) {
				realPassword = result.getString(1);
				if (realPassword.equals(password)) {
					System.err.println("[DB login] password verified.");
					return VERIFIED;
				} else {
					System.err.println("[DB login] password not match for user " + email + ". real password:"
							+ realPassword + ",given password:" + password);
					return NOT_MATCH;
				}
			} else {
				System.err.println("[DB login] no user record for " + email);
				return USER_NOT_FOUND;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return SQL_FAIL;
		}
	}

	public void insertRecord(String email, String passwd) {
		String query = " insert into " + tableName + "(email,password)" + " values (?, ?)";
		PreparedStatement preparedStmt = null;
		try {
			preparedStmt = connection.prepareStatement(query);
			preparedStmt.setString(1, email);
			preparedStmt.setString(2, passwd);
			preparedStmt.execute();
			System.err.println("[DB login] insert record success! email:" + email + ",password:" + passwd);
		} catch (SQLException e) {
			e.printStackTrace();
			System.err.println("[DB login] insert record fail! email:" + email + ",password:" + passwd);
		}
	}
}
