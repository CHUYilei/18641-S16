package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.JSONException;
import org.json.JSONObject;

public class DBUserProfileHandler {
	private static Connection connection = null;
	private static String tableName = "user_profile";
	
	/* error code */
	public static final int ERROR_DUPLICATE_USER = -2;
	public static final int ERROR_NO_USER = -3;


	public DBUserProfileHandler() {
		connection = DBConnectionHandler.getConnection();
		createTable();
	}

	/**
	 * create table if not exists
	 * return 
	 */
	private void createTable() {
		String sql = "CREATE TABLE IF NOT EXISTS "+ tableName
				+ "(user_id INT PRIMARY KEY AUTO_INCREMENT,user_name varchar(50), gender varchar(10), "
				+ "description varchar(200), email varchar(50) NOT NULL, "
				+ "FOREIGN KEY user_f_key (email) REFERENCES user_login(email));";
		DBConnectionHandler.executeSqlNoReturn(sql);
	}

	private ResultSet getProfileRecord(String email) {
		PreparedStatement ps = null;
		ResultSet result = null;
		try {
			ps = connection.prepareStatement("select * from "+tableName+" where (email=?);");
			ps.setString(1, email);
			result = ps.executeQuery();

			return result;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	public int insertRecord(String username,String gender,String description,String email) {
		if(getUserID(email) > 0){
			return ERROR_DUPLICATE_USER;
		}
		
		String query = "insert into "+tableName+"(user_name,gender,description,email) values (?,?,?,?,?);";
		PreparedStatement preparedStmt = null;
		try {
			preparedStmt = connection.prepareStatement(query);
			preparedStmt.setString(1, username);
			preparedStmt.setString(2, gender);
			preparedStmt.setString(3, description);
			preparedStmt.setString(4, email);
			preparedStmt.execute();
			System.err.println("[DB user_profile] insert record success! username:"
					+username+",gender:"+gender+",descr:"+description+",email"+email);
		} catch (SQLException e) {
			e.printStackTrace();
			System.err.println("[DB user_profile] insert record fail! username:"
					+username+",gender:"+gender+",descr:"+description+",email:"+email);
		}
		
		return getUserID(email);
	}
	
	public int getUserID(String email){
		ResultSet res = getProfileRecord(email);
		try {
			if(res.next()) return res.getInt(1);
			else System.err.println("[UserProfileDB] cannot find record for "+email);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ERROR_NO_USER;
	}
	
	public JSONObject getUserProfile(String email){
		ResultSet res = getProfileRecord(email);
		
		JSONObject obj = new JSONObject();
		try {
			if(res.next()){
				obj.put("user_id", res.getInt(1));
				obj.put("user_name", res.getString(2));
				obj.put("gender", res.getString(3));
				obj.put("description", res.getString(4));
				obj.put("email", res.getString(5));
			
				return obj;	
			}else{
				return null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return null;
	}
}
