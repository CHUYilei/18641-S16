package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * store calling info for background periodic check in app
 * 
 * columns: 
 * callee_id (int),room_id (int),caller_id(int)
 */
public class DBCallingHandler {
	private static Connection connection = null;
	private static String tableName = "calling";
	
	public DBCallingHandler() {
		connection = DBConnectionHandler.getConnection();
		createTable();
	}

	/**
	 * create table if not exists
	 * return 
	 */
	private void createTable() {
		String sql = "CREATE TABLE IF NOT EXISTS "+ tableName
				+ "(callee_id INT PRIMARY KEY,room_id INT,caller_id INT,type varchar(10),room_name varchar(100));";
		DBConnectionHandler.executeSqlNoReturn(sql);
	}

	public ResultSet getCallingRecord(int calleeID) {
		PreparedStatement ps = null;
		ResultSet result = null;
		try {
			ps = connection.prepareStatement("select * from "+tableName+" where (callee_id=?);");
			ps.setInt(1, calleeID);
			result = ps.executeQuery();
			return result;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * Whether callee has a caller
	 * @return true if callee has valid caller id
	 */
	public JSONObject isCalleeBusy(int calleeID){
		ResultSet res = getCallingRecord(calleeID);
		JSONObject jsonFinal = new JSONObject();		
		boolean isBusy = false;
		try {
			isBusy = (res != null && res.next() && res.getInt(3) > 0); //id<0 == available
			if(isBusy){
				jsonFinal.put("isBusy", true);
				jsonFinal.put("room_id", res.getInt(2));
				jsonFinal.put("caller_id", res.getInt(3));
				jsonFinal.put("type", res.getString(4));
				jsonFinal.put("room_name", res.getString(5));
				
				// immediately set to available
				updateCalling(calleeID,-1,-1,"none","none");
				System.err.println("[DBCalling] after checking to be busy, set to be available");
			}else{
				jsonFinal.put("isBusy", false);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return jsonFinal;
	}

	/**
	 * Assume callee currently available
	 * If callee not exists, insert new
	 * if exists, update the value
	 */
	public void updateCalling(int calleeID,int callerID,int roomID,String type,String roomName){
		ResultSet res = getCallingRecord(calleeID);
		try {
			if(res == null || !res.next()){ //insert
				String query = "insert into "+tableName+"(callee_id,room_id,caller_id,type,room_name) values (?,?,?,?,?);";
				PreparedStatement preparedStmt = null;
				try {
					preparedStmt = connection.prepareStatement(query);
					preparedStmt.setInt(1, calleeID);
					preparedStmt.setInt(2, roomID);
					preparedStmt.setInt(3, callerID);
					preparedStmt.setString(4, type);
					preparedStmt.setString(5, roomName);
					preparedStmt.execute();
					System.err.println("[DB calling] insert record success! callee:"
							+calleeID+",caller:"+callerID+",room:"+roomID+",type:"+type+",roomName:"+roomName);
				} catch (SQLException e) {
					e.printStackTrace();
					System.err.println("[DB user_profile] insert record fail! callee:"
							+calleeID+",caller:"+callerID+",room:"+roomID+",type:"+type+",roomName:"+roomName);
				}
			}else{	//update
				PreparedStatement update = connection.prepareStatement
					    ("UPDATE "+tableName+" SET room_id = ?, caller_id = ?,type = ?,room_name = ? WHERE callee_id = ?");
				update.setInt(1, roomID);
				update.setInt(2,callerID);
				update.setString(3, type);
				update.setString(4, roomName);
				update.setInt(5,calleeID);
				update.execute();
				System.err.println("[DB calling] update record success! callee:"
						+calleeID+",caller:"+callerID+",room:"+roomID+",type:"+type+",roomName:"+roomName);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
