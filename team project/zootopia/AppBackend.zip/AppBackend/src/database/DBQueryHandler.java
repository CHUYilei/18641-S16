package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DBQueryHandler {
	private static Connection connection = null;

	public DBQueryHandler() {
		connection = DBConnectionHandler.getConnection();
		createTable();
		/* Sample usage for insert statement */
		/*insertRecord("message_chatroom", 
				"from_user_id", "10",
				"to_user_id","20",
				"room_id", "999",
				"time", LocalDateTime.now().toString(),
				"title", "greetings!",
				"content", "Hello, can I know you?",
				"status", "T");*/
	}
	
	/**
	 * Create tables when necessary
	 */
	private void createTable() {
		createLoginTable();
		createProfileTable();
		createRelationTable();
		createChatroomProfileTable();
		//createMsgChatroomTable();
		createChatroomMemberListTable();
	}
	
	/**
	 * create login table if not exists
	 * return 
	 */
	private void createLoginTable() {
		String sql = "CREATE TABLE IF NOT EXISTS user_login"
				+ "(email varchar(50) PRIMARY KEY,"
				+ " password varchar(20))";
		DBConnectionHandler.executeSqlNoReturn(sql);
	}
	
	private void createProfileTable() {
		String sql = "CREATE TABLE IF NOT EXISTS user_profile"
				+ "(user_id INT PRIMARY KEY AUTO_INCREMENT, user_name varchar(50), gender varchar(10), "
				+ "birth_date date, description varchar(200), email varchar(50) NOT NULL, "
				+ "FOREIGN KEY user_profile(email) REFERENCES user_login(email));";
		DBConnectionHandler.executeSqlNoReturn(sql);
	}
	
	private void createRelationTable() {
		String sql = "CREATE TABLE IF NOT EXISTS relationship (user_id INT NOT NULL, "
				+ "friend_id INT NOT NULL, primary key(user_id, friend_id), "
				+ "FOREIGN KEY userid_f_key (user_id) REFERENCES user_profile(user_id), "
				+ "FOREIGN KEY friendid_f_key (friend_id) REFERENCES user_profile(user_id))";
		DBConnectionHandler.executeSqlNoReturn(sql);
	}
	
	private void createChatroomProfileTable() {
		String sql = "CREATE TABLE IF NOT EXISTS chatroom_profile ("
				+ "room_id INT PRIMARY KEY AUTO_INCREMENT,host_id INT NOT NULL, "
				+ "room_name varchar(100), "
				+ "room_description varchar(250), "
				+ "FOREIGN KEY hostid_f_key (host_id) REFERENCES user_profile(user_id))";
		DBConnectionHandler.executeSqlNoReturn(sql);
	}
	
	private void createChatroomMemberListTable() {
		String sql = "CREATE TABLE IF NOT EXISTS chatroom_member_list ("
				+ "room_id INT NOT NULL, user_id INT NOT NULL,"
				+ "primary key(user_id, room_id), "
				+ "FOREIGN KEY userid_f_key (user_id) REFERENCES user_profile(user_id), "
				+ "FOREIGN KEY roomid_f_key (room_id) REFERENCES chatroom_profile(room_id));";
		DBConnectionHandler.executeSqlNoReturn(sql);
	}
	
	
	/*private void createMsgChatroomTable() {
		String sql = "CREATE TABLE IF NOT EXISTS message_chatroom"
				+ "(msg_id INT PRIMARY KEY AUTO_INCREMENT, from_user_id INT NOT NULL, "
				+ "to_user_id INT NOT NULL, room_id INT NOT NULL, time date, "
				+ "title varchar(100), content varchar(500), status char(1))";
		DBConnectionHandler.executeSqlNoReturn(sql);
	}*/
	
	
	
	/**
	 * Wrapper for select statement to retrieve record from database
	 * @param tableName
	 * @param args
	 * @return
	 */
	private ResultSet getRecord(String tableName, String... args) {
		PreparedStatement ps = null;
		ResultSet result = null;
		StringBuilder sb = new StringBuilder("select * from " + tableName +" where (");
		for (int i = 0; i < args.length; i+=2)
			sb.append(args[i] + "=? and ");
		int l = sb.length();
		sb.delete(l - 5, l);
		sb.append(')');
		String query = sb.toString();
		System.out.println("query:" + query);
		try {
			ps = connection.prepareStatement(query);
			for (int i = 0; i < args.length/2; i++)
				ps.setString(i+1, args[i*2 + 1]);
			result = ps.executeQuery();
			return result;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * Insert a record into database
	 * @param tableName
	 * @param args column_name1, column_value1, column_name2, column_value2,...
	 */
	public void insertRecord(String tableName, String... args) {
		StringBuilder sb = new StringBuilder("insert into "+ tableName + " (");
		for (int i = 0; i < args.length; i+=2) 
			sb.append(args[i] + ",");
		sb.deleteCharAt(sb.length() -1 );
		sb.append(") values (");
		for (int i = 0; i < args.length; i+=2) 
			sb.append("?,");
		sb.deleteCharAt(sb.length() - 1);
		sb.append(")");
		String query = sb.toString();
		System.out.println("query:" + query);
		//String query = "insert into "+ tableName + "(from_user_id,to_user_id,room_id,"
		//		+ "time,title,content,status) values (?,?,?,?,?,?,?);";
		PreparedStatement preparedStmt = null;
		try {
			preparedStmt = connection.prepareStatement(query);
			for (int i = 0; i < args.length/2; i++)
				preparedStmt.setString(i+1, args[i*2 + 1]);
			preparedStmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		printInfo(tableName, args);
	}
	
	/**
	 * Update a record, only support one where condition. Use map could support
	 * multiple conditions.
	 * @param tableName
	 * @param whereCondition
	 * @param args
	 */
	public void updateRecord(String tableName, Map<String,String> whereCondition,
			String... args) {
		StringBuilder sb = new StringBuilder("UPDATE "+ tableName + " SET ");
		for (int i = 0; i < args.length; i+=2) 
			sb.append(args[i] + "=?,");
		sb.deleteCharAt(sb.length() -1);
		sb.append(" where ");
		for (Map.Entry<String, String> e: whereCondition.entrySet()) {
			sb.append(e.getKey()  + "=" + e.getValue());
			sb.append(" and ");
		}
		int l = sb.length();
		sb.delete(l - 5, l);
		String query = sb.toString();
		System.out.println("query:" + query);
		//String query = "insert into "+ tableName + "(from_user_id,to_user_id,room_id,"
		//		+ "time,title,content,status) values (?,?,?,?,?,?,?);";
		PreparedStatement preparedStmt = null;
		try {
			preparedStmt = connection.prepareStatement(query);
			for (int i = 0; i < args.length/2; i++)
				preparedStmt.setString(i+1, args[i*2 + 1]);
			preparedStmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.err.println(preparedStmt.toString());
	}
	
	/**
	 * Delete a record from database
	 * @param tableName
	 * @param whereCondition
	 */
	public void delelteRecord(String tableName, Map<String,String> whereCondition) {
		StringBuilder sb = new StringBuilder("DELETE from "+ tableName + " where ");
		for (Map.Entry<String, String> e: whereCondition.entrySet()) {
			sb.append(e.getKey()  + "=" + e.getValue());
			sb.append(" and ");
		}
		int l = sb.length();
		sb.delete(l - 5, l);
		String query = sb.toString();
		System.out.println("query:" + query);
		PreparedStatement preparedStmt = null;
		try {
			preparedStmt = connection.prepareStatement(query);
			preparedStmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.err.println(preparedStmt.toString());
	}
	
	/**
	 * Get last primary id of insert operation
	 * @return
	 */
	public String getInsertId() {
		PreparedStatement preparedStmt = null;
		try {
			preparedStmt = connection.prepareStatement("select LAST_INSERT_ID()");
			ResultSet result = preparedStmt.executeQuery();
			if(result != null && result.next()){	
				return result.getString(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Function to print DEBUG information
	 * @param tableName
	 * @param args
	 */
	private void printInfo(String tableName, String... args) {
		StringBuilder sb = new StringBuilder("[DB ");
		sb.append(tableName + "] insert/update record success!");
		for (int i = 0; i < args.length; i+=2) {
			sb.append(args[i] + ":");
			sb.append(args[i+1] + ";");
		}
		sb.deleteCharAt(sb.length() - 1);
		System.err.println(sb.toString());
	}
	
	
	/**
	 * Retrieve record from database and convert to JSON format
	 * @param tableName
	 * @param args column_name1, column_name2,..., colum_nameN
	 * @return JSONObject
	 */
	public JSONObject getJSONObject(String tableName, String... args){
		ResultSet res = getRecord(tableName, args);
		
		JSONObject obj = new JSONObject();
		try {
			if(res.next()){
				ResultSetMetaData metaData = res.getMetaData();
				int count = metaData.getColumnCount();
				for (int i = 1; i <= count; i++) {
					obj.put(metaData.getColumnLabel(i), res.getString(i));
				}
				return obj;	
			}else{
				return null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Retrieve multiple records from database and convert to JSON format
	 * @param tableName
	 * @param args column_name1, column_name2,..., colum_nameN
	 * @return JSONArray
	 */
	public JSONArray getJSONObjectArray(String query){
		PreparedStatement preparedStmt = null;
		ResultSet res = null;
		try {
			preparedStmt = connection.prepareStatement(query);
			res = preparedStmt.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.err.println(preparedStmt.toString());		
		JSONArray array = new JSONArray();
		try {
			while(res != null && res.next()){
				JSONObject obj = new JSONObject();
				ResultSetMetaData metaData = res.getMetaData();
				int count = metaData.getColumnCount();
				for (int i = 1; i <= count; i++) {
					obj.put(metaData.getColumnLabel(i), res.getString(i));
				}
				array.put(obj);
			}
			return array;
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return null;
	}

}

